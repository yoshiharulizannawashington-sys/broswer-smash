import * as THREE from 'three';

/**
 * Starter combat data and hit resolution. This is deliberately engine-agnostic:
 * connect hitConfirm() to your animation events / hitbox checks.
 */
export const DEFAULT_MOVES = {
  light:  { name: 'Pulse Jab', damage: 7,  stun: 0.22, knockback: 4.5, hitStop: 0.045, range: 2.0 },
  heavy:  { name: 'Nova Breaker', damage: 16, stun: 0.55, knockback: 9.0, hitStop: 0.085, range: 2.7 },
  special:{ name: 'Arc Surge', damage: 21, stun: 0.72, knockback: 12,  hitStop: 0.11,  range: 5.0 }
};

export class CombatantState {
  constructor({ maxHealth = 100 } = {}) {
    this.maxHealth = maxHealth;
    this.health = maxHealth;
    this.stunRemaining = 0;
    this.invulnerableRemaining = 0;
    this.hitStopRemaining = 0;
    this.isBlocking = false;
    this.isKO = false;
  }

  update(dt) {
    this.stunRemaining = Math.max(0, this.stunRemaining - dt);
    this.invulnerableRemaining = Math.max(0, this.invulnerableRemaining - dt);
    this.hitStopRemaining = Math.max(0, this.hitStopRemaining - dt);
    if (this.health <= 0) this.isKO = true;
  }

  receiveHit(move, attackerPosition, defenderPosition, physicsController) {
    if (this.isKO || this.invulnerableRemaining > 0) return { hit: false };
    const blocked = this.isBlocking;
    const damage = blocked ? Math.max(1, Math.round(move.damage * 0.2)) : move.damage;
    this.health = Math.max(0, this.health - damage);

    if (!blocked) {
      this.stunRemaining = Math.max(this.stunRemaining, move.stun);
      this.hitStopRemaining = Math.max(this.hitStopRemaining, move.hitStop);
      const direction = new THREE.Vector3().subVectors(defenderPosition, attackerPosition);
      physicsController?.applyKnockback(direction, move.knockback, move.knockback * 0.32);
    }

    if (this.health <= 0) this.isKO = true;
    return { hit: true, blocked, damage, ko: this.isKO };
  }
}
