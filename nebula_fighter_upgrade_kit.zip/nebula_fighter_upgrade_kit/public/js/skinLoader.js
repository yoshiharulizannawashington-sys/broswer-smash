import * as THREE from 'three';

export class SkinManager {
  constructor() {
    this.textureLoader = new THREE.TextureLoader();
    this.textureCache = new Map();
  }

  async applySkinTexture(characterModel, skinTextureUrl) {
    if (!characterModel || !skinTextureUrl) return;

    let texture = this.textureCache.get(skinTextureUrl);
    if (!texture) {
      texture = await this.textureLoader.loadAsync(skinTextureUrl);
      texture.flipY = false;
      texture.colorSpace = THREE.SRGBColorSpace;
      this.textureCache.set(skinTextureUrl, texture);
    }

    characterModel.traverse((child) => {
      if (!child.isMesh || !child.material) return;

      const materials = Array.isArray(child.material)
        ? child.material
        : [child.material];

      const replacements = materials.map((material) => {
        const cloned = material.clone();
        cloned.map = texture;
        cloned.needsUpdate = true;
        return cloned;
      });

      child.material = Array.isArray(child.material) ? replacements : replacements[0];
    });
  }

  dispose() {
    for (const texture of this.textureCache.values()) texture.dispose();
    this.textureCache.clear();
  }
}
