import * as THREE from 'three';

/**
 * Enclosed 3D arena foundation.
 * This provides visual geometry and radial bounds; it is not a full rigid-body
 * collision engine. Add Rapier or another physics engine for complex geometry.
 */
export class EnclosedStage3D {
  constructor(scene, mapConfig = {}) {
    this.scene = scene;
    this.config = mapConfig;
    this.arenaRadius = mapConfig.radius ?? 35;
    this.wallHeight = mapConfig.wallHeight ?? 14;
    this.wallThickness = mapConfig.wallThickness ?? 1.2;
    this.floorY = mapConfig.floorY ?? 0;
    this.objects = [];
    this.initLighting();
    this.buildGeometry();
  }

  initLighting() {
    const hemi = new THREE.HemisphereLight(0xc5d9ff, 0x171321, 1.6);
    this.scene.add(hemi);
    this.objects.push(hemi);

    const key = new THREE.DirectionalLight(0xffe4c4, 3.0);
    key.position.set(18, 28, 12);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.camera.near = 0.5;
    key.shadow.camera.far = 100;
    key.shadow.camera.left = -this.arenaRadius;
    key.shadow.camera.right = this.arenaRadius;
    key.shadow.camera.top = this.arenaRadius;
    key.shadow.camera.bottom = -this.arenaRadius;
    this.scene.add(key);
    this.objects.push(key);

    const rim = new THREE.PointLight(0x3a8dff, 35, this.arenaRadius * 1.8);
    rim.position.set(-10, 6, -8);
    this.scene.add(rim);
    this.objects.push(rim);
  }

  buildGeometry() {
    const floorGeo = new THREE.CylinderGeometry(
      this.arenaRadius, this.arenaRadius, 1.2, 96, 1, false
    );
    const floorMat = new THREE.MeshStandardMaterial({
      color: this.config.floorColor ?? 0x202636,
      roughness: 0.32,
      metalness: 0.65
    });
    this.floorMesh = new THREE.Mesh(floorGeo, floorMat);
    this.floorMesh.position.y = this.floorY - 0.6;
    this.floorMesh.receiveShadow = true;
    this.scene.add(this.floorMesh);
    this.objects.push(this.floorMesh);

    // Glowing perimeter ring.
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(this.arenaRadius - 0.7, 0.16, 12, 128),
      new THREE.MeshStandardMaterial({
        color: 0x4e9fff,
        emissive: 0x174cff,
        emissiveIntensity: 2.2,
        metalness: 0.6,
        roughness: 0.25
      })
    );
    ring.rotation.x = Math.PI / 2;
    ring.position.y = this.floorY + 0.08;
    this.scene.add(ring);
    this.objects.push(ring);

    // Invisible circular boundary. Keep this separate from visible geometry.
    const wallGeo = new THREE.CylinderGeometry(
      this.arenaRadius, this.arenaRadius, this.wallHeight, 96, 1, true
    );
    const wallMat = new THREE.MeshBasicMaterial({
      side: THREE.BackSide,
      color: 0x3c9dff,
      transparent: true,
      opacity: this.config.showForcefield ? 0.12 : 0,
      depthWrite: false
    });
    this.wallMesh = new THREE.Mesh(wallGeo, wallMat);
    this.wallMesh.position.y = this.floorY + this.wallHeight / 2;
    this.scene.add(this.wallMesh);
    this.objects.push(this.wallMesh);

    // Arena pillars make the space feel enclosed without expensive assets.
    const pillarMat = new THREE.MeshStandardMaterial({
      color: 0x30394b, metalness: 0.8, roughness: 0.3,
      emissive: 0x071a38, emissiveIntensity: 0.7
    });
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      const pillar = new THREE.Mesh(
        new THREE.BoxGeometry(1.1, this.wallHeight * 0.85, 1.1),
        pillarMat
      );
      pillar.position.set(
        Math.cos(a) * (this.arenaRadius - 1.1),
        this.floorY + this.wallHeight * 0.425,
        Math.sin(a) * (this.arenaRadius - 1.1)
      );
      pillar.rotation.y = -a;
      pillar.castShadow = true;
      pillar.receiveShadow = true;
      this.scene.add(pillar);
      this.objects.push(pillar);
    }
  }

  constrainFighter(position, padding = 1.25) {
    const maxRadius = Math.max(1, this.arenaRadius - padding);
    const dx = position.x;
    const dz = position.z;
    const distance = Math.hypot(dx, dz);

    if (distance > maxRadius) {
      const scale = maxRadius / distance;
      position.x *= scale;
      position.z *= scale;
    }

    if (position.y < this.floorY) position.y = this.floorY;
    return position;
  }

  dispose() {
    for (const object of this.objects) {
      this.scene.remove(object);
      object.geometry?.dispose?.();
      if (Array.isArray(object.material)) {
        object.material.forEach((m) => m.dispose?.());
      } else {
        object.material?.dispose?.();
      }
    }
    this.objects.length = 0;
  }
}
