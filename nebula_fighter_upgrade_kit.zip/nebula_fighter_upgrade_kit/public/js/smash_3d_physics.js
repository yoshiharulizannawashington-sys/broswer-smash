import * as THREE from 'three';

/**
 * Lightweight character movement controller.
 * Call update() once per animation frame with deltaSeconds from the clock.
 * For production combat, use a rigid-body engine for complex collisions.
 */
export class Fighter3DPhysics {
  constructor(characterMesh, options = {}) {
    this.mesh = characterMesh;
    this.position = characterMesh.position;
    this.velocity = new THREE.Vector3();
    this.moveSpeed = options.moveSpeed ?? 7.5;      // world units / second
    this.groundAcceleration = options.acceleration ?? 38;
    this.friction = options.friction ?? 12;
    this.jumpSpeed = options.jumpSpeed ?? 10.5;
    this.gravity = options.gravity ?? 27;
    this.isGrounded = true;
    this.facing = 1;
  }

  update(inputs, targetOpponentPosition, stage, deltaSeconds) {
    const dt = Math.min(Math.max(deltaSeconds || 0, 0), 1 / 20);
    const move = new THREE.Vector3(
      (inputs.right ? 1 : 0) - (inputs.left ? 1 : 0),
      0,
      (inputs.down ? 1 : 0) - (inputs.up ? 1 : 0)
    );

    if (move.lengthSq() > 1) move.normalize();

    if (move.lengthSq() > 0) {
      const desiredX = move.x * this.moveSpeed;
      const desiredZ = move.z * this.moveSpeed;
      this.velocity.x = THREE.MathUtils.damp(
        this.velocity.x, desiredX, this.groundAcceleration, dt
      );
      this.velocity.z = THREE.MathUtils.damp(
        this.velocity.z, desiredZ, this.groundAcceleration, dt
      );
    } else {
      this.velocity.x = THREE.MathUtils.damp(this.velocity.x, 0, this.friction, dt);
      this.velocity.z = THREE.MathUtils.damp(this.velocity.z, 0, this.friction, dt);
    }

    if (inputs.jump && this.isGrounded) {
      this.velocity.y = this.jumpSpeed;
      this.isGrounded = false;
    }

    if (!this.isGrounded) this.velocity.y -= this.gravity * dt;

    this.position.x += this.velocity.x * dt;
    this.position.y += this.velocity.y * dt;
    this.position.z += this.velocity.z * dt;

    if (stage) stage.constrainFighter(this.position);

    if (this.position.y <= (stage?.floorY ?? 0)) {
      this.position.y = stage?.floorY ?? 0;
      this.velocity.y = 0;
      this.isGrounded = true;
    }

    if (targetOpponentPosition) {
      const dx = targetOpponentPosition.x - this.position.x;
      const dz = targetOpponentPosition.z - this.position.z;
      if (Math.abs(dx) + Math.abs(dz) > 0.001) {
        this.mesh.rotation.y = Math.atan2(dx, dz);
        this.facing = dx >= 0 ? 1 : -1;
      }
    }
  }

  applyKnockback(direction, strength, verticalStrength = 0) {
    const dir = direction.clone().setY(0);
    if (dir.lengthSq() > 0) dir.normalize();
    this.velocity.x = dir.x * strength;
    this.velocity.z = dir.z * strength;
    this.velocity.y = verticalStrength;
    this.isGrounded = false;
  }
}
