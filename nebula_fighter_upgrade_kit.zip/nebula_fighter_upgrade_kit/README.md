# Nebula Fighter — upgrade kit

A starter code bundle for growing the existing Three.js `broswer-smash` platform
fighter into a more cinematic 3D combat prototype.

Start with `docs/INTEGRATION.md`. This kit contains code foundations, not finished
high-definition assets, online matchmaking, or a complete game.

Suggested milestones:
1. Integrate and validate arena, movement, and rendering.
2. Add rigged original characters and animation blending.
3. Add attack hitboxes, combos, block, dodge, stun, hit-stop, and KO flow.
4. Add AI opponents and a polished character / arena selection UI.
5. Add online multiplayer with authoritative server simulation.
6. Expand the arena into a larger explorable world only after the combat loop is stable.
