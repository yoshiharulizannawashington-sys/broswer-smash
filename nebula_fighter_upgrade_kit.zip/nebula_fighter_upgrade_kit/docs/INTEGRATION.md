# Nebula Fighter upgrade kit

This kit is a starter foundation for extending the existing Three.js `broswer-smash`
project. It is not a complete AAA game and has not been integrated into your remote
GitHub repository automatically.

## Files included

- `public/js/smash_3d_stage.js` — enclosed circular arena, lighting, bounds, pillars.
- `public/js/smash_3d_physics.js` — delta-time movement, jump/gravity, facing, knockback.
- `public/js/smash_render_pipeline.js` — ACES tone mapping, shadows, bloom.
- `public/js/skinLoader.js` — cached replacement textures for glTF meshes.
- `public/js/combatCore.js` — starter move definitions, health, stun, block, hit-stop, knockback.

## Dependencies

The modules expect Three.js and its `examples/jsm` modules to already be installed,
as they are in a typical Three.js project. Keep the versions of `three` and its
post-processing modules aligned.

## Integration outline

1. Copy the files under `public/js/` into the equivalent folder in your project.
2. In the existing scene setup, create `EnclosedStage3D(scene, { radius: 35 })`.
3. Create one `Fighter3DPhysics` instance for each loaded fighter mesh.
4. Use a `THREE.Clock` in your animation loop and pass `clock.getDelta()` to each
   controller's `update(inputs, opponent.position, stage, dt)`.
5. Use `createRealismPipeline(canvas, scene, camera)` and render via
   `composer.render()` instead of `renderer.render(scene, camera)`.
6. Connect attack animation events to `CombatantState.receiveHit()`. Add actual
   hitbox overlap checks before applying damage; move range alone is not a hitbox.
7. Load rigged `.glb` characters with `GLTFLoader` and use `THREE.AnimationMixer` to
   blend idle, run, jump, attack, block, hit, and KO animations.
8. Test keyboard/controller inputs and collision behavior on the target browser.

## Important engineering notes

- The movement controller uses world-units per second; tune speeds to your character
  scale. It is not a replacement for a rigid-body physics engine.
- The circular arena bounds do not collide with arbitrary stage objects.
- For production-quality ragdolls, moving platforms, complex collision meshes, and
  robust character controllers, integrate a physics engine such as Rapier.
- Online multiplayer needs a server-authoritative simulation, input validation,
  latency handling, and anti-cheat measures. Do not trust client-reported damage.
- Keep all model, animation, sound, and texture licenses documented. Prefer original
  assets or assets whose licenses allow your intended use.
- Do not place API keys, private tokens, or passwords in client-side code.
